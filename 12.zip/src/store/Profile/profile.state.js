export const ProfileState = {
            id: 1,
            name: "Symbat",
            surname: "Isamidinove",
            login: "symbat_fronted", 
            photo: "logo"

}