export const newsItemState = {
   item: {
    title: "Bek",
    date: "",
    content: "",
    author: "",
   }

}